﻿namespace JobSearchApp_MVC.Models
{
    public class StoredData
    {
        public static string StoredEmail { get; set; }
        public static string StoredJWToken { get; set; }

        public static int StoredId { get; set; }
    }
}
