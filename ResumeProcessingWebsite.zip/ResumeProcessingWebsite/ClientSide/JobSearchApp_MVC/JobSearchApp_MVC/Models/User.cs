﻿namespace JobSearchApp_MVC.Models
{
    public class User
    {
        public string email { get; set; }
        public string password { get; set; }

    }

}
