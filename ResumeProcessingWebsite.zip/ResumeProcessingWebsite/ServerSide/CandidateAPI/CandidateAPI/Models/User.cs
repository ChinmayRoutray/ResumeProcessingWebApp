﻿namespace ConsumerAPI.Models
{
    public class User
    {
        public string email { get; set; }
        public string password { get; set; }

        //public static string storedUsername { get; set; } = string.Empty;
    }

}
